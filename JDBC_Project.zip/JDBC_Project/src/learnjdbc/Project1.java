package learnjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Project1 {
	public static void main(String[] args) throws SQLException,ClassNotFoundException {
		
		
		// TODO Auto-generated method stub
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/employees_database","root","Ashu@123");
			System.out.println(conn);
			Statement statement = conn.createStatement();
			ResultSet resultSet= statement.executeQuery("select *from employee");
			
			while(resultSet.next())
			{
			
			System.out.println(resultSet.getString("name"));
			
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}

}

