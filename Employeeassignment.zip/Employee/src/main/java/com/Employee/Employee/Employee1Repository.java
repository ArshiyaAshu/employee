package com.Employee.Employee;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Transactional

public class Employee1Repository {
	
	@Autowired
	EntityManager em;
	
	public Employee1 findById(Long id) {
		return em.find(Employee1.class, id);
		

	}
   public void deleteById(Long id) 
{

		Employee1 employee= findById(id);
	    em.remove(employee);
}
		
	public Employee1 save(Employee1 employee)
	{
		if(employee.getId()==null) {
			em.persist(employee);
		}else
		{
			em.merge(employee);
		}
		return employee;
		
		}
	
}

