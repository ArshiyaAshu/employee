insert into Employee1(id,name,designation) values(1,'Arshiya','software Engineer');
insert into Employee1(id,name,designation) values(2,'manha','system Engineer');
insert into Employee1(id,name,designation) values(3,'mahveen','product Engineer');
insert into Employee1(id,name,designation) values(4,'Akhila',' Engineer');
insert into Employee1(id,name,designation) values(5,'manisha','software Engineer');