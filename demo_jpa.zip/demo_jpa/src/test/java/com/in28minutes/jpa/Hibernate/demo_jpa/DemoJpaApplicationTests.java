package com.in28minutes.jpa.Hibernate.demo_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
